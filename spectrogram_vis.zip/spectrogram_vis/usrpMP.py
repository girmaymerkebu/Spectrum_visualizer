import multiprocessing
from time import sleep, time
import random
import uhd
import json
import numpy as np
from scipy import signal
# import tensorflow as tf
import matplotlib.pyplot as plt
import sys

import Communication.settings as settings
import Communication.proto.msg_tech_rec_pb2 as proto_msg
from Communication.sender_tech import Sender


from sklearn.preprocessing import minmax_scale

trecv = 1 # seconds
sr = 10e06 # bandwidth
rx_gain = 50 # dB
#spec_time = 0.050 # s
spec_time = 0.50
#rssi_threshold = 0.05
rssi_threshold = 0.09
#arr_channels = [ 11, ] # change here!
#dic_freq = {11: 5210e6 , } # 1:2412e6 6: 2437e6 11: 2462e6    #licensed:    2655e6   2535e6
#dic_freq = {11: 2412e6 , } # 1:2412e6 6: 2437e6 11: 2462e6    #licensed:    2655e6   2535e6
#arr_devices = [ {"freq":dic_freq[arr_channels[0]], "serial":"315C7B8"},] #30AA08D
                # {"freq":dic_freq[arr_channels[1]], "serial":"315C7B8"}] 
		        #{"freq":dic_freq[arr_channels[2]], "serial":"3135A2A"}] # 315C7B8

#dict_channels = {"315C7B8":arr_channels[0],} # "3135A2A":arr_channels[1]} #, "316B6DB":arr_channels[2]} 3135A2A
arr_channels = [ 1, 6, 11 ] # change here!
dic_freq = {1: 2412e6 ,  6: 2437e6 , 11: 2462e6}    #licensed:    2655e6   2535e6
arr_devices = [ {"freq":dic_freq[arr_channels[0]], "serial":"315C7B8"},
                 {"freq":dic_freq[arr_channels[1]], "serial":"315C7B8"} 
		        {"freq":dic_freq[arr_channels[2]], "serial":"3135A2A"}] # 315C7B8

dict_channels = {"315C7B8":arr_channels[0], "3135A2A":arr_channels[1], "316B6DB":arr_channels[2]} #3135A2A


nr_usrp = len(arr_devices)


sens_shot = 2000  # sample bin for classification

def init(queue):
    global PID
    PID = int(queue.get())
    print(f"Initializing proccess {PID}")

    device = arr_devices[PID]
    global usrp
    usrp = uhd.usrp.MultiUSRP(f"serial={device['serial']}")

    print("DONE")

def f(x):
    global PID
    device = arr_devices[PID]
    global usrp
    freq = arr_devices[PID]["freq"]

    print(f"Capturing samples")

    while True:
        try:
            IQ_data = usrp.recv_num_samps(int((trecv * int(sr)) / 1) , freq=freq, rate=10e6, gain=rx_gain)
            break
        except Exception as e:
            print(e)

    print("Starting preprocessing IQ...")
    start = time()

    shorter =  IQ_data[:, 0:IQ_data.shape[1] - IQ_data.shape[1] % sens_shot] # trim 
    result = np.reshape(shorter, (int(shorter.shape[1] / sens_shot), sens_shot))
    data = np.fft.fft(result, axis=1)

    # data = result # no fft

    complexdata = np.float32(np.concatenate(
        [data.real, data.imag], axis=1)) # still check if 32 bit?

    # vdata = minmax_scale(complexdata, feature_range=(-1, 1), axis=1, copy=True)

    vdata = np.reshape(complexdata, (result.shape[0], 250, 16, 1)) # reshape


    # Spec
    # create spectrogram
    f, t, Sxx = signal.spectrogram(
        shorter[0, :int(20000000 * spec_time)], sr, return_onesided=False, nperseg=128, nfft=128)

    # reduce precision of spectrogram
    reduce_res = 20
    Sxx = Sxx[:, 0:Sxx.shape[1] - Sxx.shape[1] % reduce_res]

    # make values follow a logarithmic scale
    Sxx = np.fft.fftshift(Sxx, axes=0)
    Sxx = 10*np.log10(abs(Sxx))

    # Export spectrogram
    fig = plt.figure(figsize=(10, 1), dpi=320,)


    plt.imshow(np.array(Sxx.tolist()), #.transpose(),
               cmap='viridis',  aspect='auto')
    # plt.colorbar()
    plt.ylabel('Frequency [Hz]')
    plt.xlabel('Time [sec]')
    plt.axis('off')
    fig.savefig(f"spectrogram{PID}.png", bbox_inches='tight') # or .pdf

    plt.close('all')

    stop = time()

    #print("[Conv]\tDone, elapsed time: {:.3f} seconds.".format(stop- start))

    return PID, vdata

def classify(IQ_data):
    print("[CLAS]\tStarted classification...")
    start = time()
    predictions = model.predict(IQ_data, batch_size=1024, verbose=2 )
    print("[CLAS]\tDone, elapsed time: {:.3f} seconds.".format(time() - start))
    predictedclasses = np.argmax(predictions, axis=1)
    conf = np.max(predictions, axis=1)

    idx_low_conf = np.where(conf<0.8)[0]
    predictedclasses[idx_low_conf] = 4

    return predictedclasses.tolist()

def threshold(IQ_data):
    start = time()

    rssi = np.abs(result[1])
    #print("Mean RSSI: ", np.mean(rssi.flatten()))

    rssi = np.reshape(rssi, (rssi.shape[0], 250 * 16))
    rssi_means = np.mean(rssi, axis=1)
    #print("RSSI window means:", np.mean(rssi_means))

    
    predictions = [ 0 if mean < rssi_threshold else 1 for mean in rssi_means]
    #print("[THRESH]\tDone, elapsed time: {:.3f} seconds.".format(time() - start))

    # plt.plot(predictions) # rssi_means
    # plt.savefig("rssimeans.png")
    # plt.close('all')

    # fig = plt.figure(figsize=(10, 1), dpi=320,)
    # plt.plot(rssi.flatten())
    # plt.ylabel('RSSI')
    # plt.xlabel('Time')
    # # plt.axis('off')
    # fig.savefig(f"RSSI.png", bbox_inches='tight')  # or .pdf
    # plt.close('all')

    return predictions

def dostatistics(labels):
    #print("[STAT]\tStarted statistics...")
    start = time()
    # Calculate spectrum occupancy & packet size
    spec_occ = dict({0:0,1:0,2:0,3:0,4:0, 5:0})
    arr_pack_sizes = dict({0:[], 1:[], 2:[],3:[],4:[]})
    last_packet = -1
    for label in labels:
        spec_occ[label] = spec_occ.get(label, 0) + (1 / len(labels) * 100) # percentage

        # count packet sizes
        if(label != 5):
            if(label == last_packet):
                arr_pack_sizes[label][-1] += 0.1 # -> 100 µs to 1 ms
            else:
                arr_pack_sizes[label].append(0.1) # -> 100 µs to 1 ms
                last_packet = label

    end = time()
   # print("[STAT]\tDone, elapsed time: {:.3f} seconds.".format(end - start))

    spec_occ_readable = {}
    spec_occ_readable['WiFi'] = spec_occ[1]
    spec_occ_readable['Noise'] = spec_occ[0]
    spec_occ_readable['LTE'] = 0
    #spec_occ_readable['5G'] = 0
    #spec_occ_readable['ITSG5'] = 0
    # spec_occ_readable = ['-'] = spec_occ[5]

    return spec_occ_readable


# Init variables, multi-processing and ZMQ
ids = range(0, nr_usrp)
manager = multiprocessing.Manager()
idQueue = manager.Queue()
sender = Sender()
message_id = 1

for i in ids:
    idQueue.put(i)

p = multiprocessing.Pool(nr_usrp, init, [idQueue])

# GPU memory dynamic growth
# physical_devices = tf.config.experimental.list_physical_devices('GPU')
# assert len(physical_devices) > 0, "Not enough GPU hardware devices available"
# tf.config.experimental.set_memory_growth(physical_devices[0], True)

# Load model
# modelFFT = "Models/modelfftv19-vgood.h5"
# modelFFT = "Models/modelfftsmall.h5"
# modelFFT = "Models/W-L-B-Z-O-N_nomorm_FT_10G_v1_modelV1.h5"
# modelFFT = "Models/W-L-B-Z-O-N_mapmin_FT_10G_v1_modelV2.h5" # good with gain of 0
# modelFFT = "Models/W-L-B-LN-N_mapmin_FT_10G_v1_model.h5" 
modelFFT = "Models/ITS_band_model.h5" # good with gain of 10 even 40
# modelFFT = "Models/W-L-B-LN-N_mapmin_IQ_10G_v1_model.h5" # Very sensitive, low gain Otherwise to much wifi
# modelFFT = "Models/W-L-B-LN-N_mapmin_FT_10G_v1_modelNOBLE.h5" # good with gain of 20

# model = tf.keras.models.load_model(modelFFT)

start = time()
# Loop for capturing and processing data
doreceive = True
while(doreceive):
    results = p.map(f, ids)

    stats = [{} for i in range(0, nr_usrp)]
    for result in results:
        # print(f"USRP {result[0]} received {result[1].shape} samples")

        #labels = classify(result[1]) # ml
        labels = threshold(result[1])  # threshold

        stat = dostatistics(labels)
        stat_pid = result[0]
        stat["Channel"] = arr_channels[stat_pid]
        stats[stat_pid] = stat

    #print(f"Sending stats:")
    for s in stats:
        
        
        print("\nCHANNEL 1:")
        print("+------------------------------------------------------------------------------------------------------------------------------+")
        print("\tNoise: {0:.1f}%\tWiFi: {1:.1f}%\tLTE: {2:.1f}%\t5G NR: {3:.1f}%\tITS-G5: {4:.1f}%\tCV2X PC5: {5:.1f}%\tOverlap: {6:.1f}% "
        .format( s['Noise'], s['WiFi'], 0, 0, 0, 0,0))
        print("+------------------------------------------------------------------------------------------------------------------------------+")
        


        print("\nCHANNEL 2:")
        print("+------------------------------------------------------------------------------------------------------------------------------+")
        print("\tNoise: {0:.1f}%\tWiFi: {1:.1f}%\tLTE: {2:.1f}%\t5G NR: {3:.1f}%\tITS-G5: {4:.1f}%\tCV2X PC5: {5:.1f}%\tOverlap: {6:.1f}% "
        .format( 100, 0, 0, 0, 0, 0,0))
        print("+------------------------------------------------------------------------------------------------------------------------------+")
        
        print("Channel {0}:\tWifi: {1:.3f}%\tNoise: {2:.3f}%"
        .format(s['Channel'],s['WiFi'], s['Noise']))
    sender.send(message_id, stats )

    message_id = message_id+1

    # export to json file
    with open("stats.json", "w") as outputfile:
        json.dump(stats, outputfile)

    results = None
    stats = None

    with open("amiquitting.huh","r") as qfile:
        status = qfile.readline()
        if(status):
            doreceive = False
            print("--- I'll quit!!! ---")
    
    stop = time()
    #print("\n\n--- [FULL]\tDone, elapsed time: {:.3f} seconds. ---\n\n\n".format(stop - start))
    start = time()
    # doreceive = input("Press enter to continue (exit with q)\n") != "q"

p.close()

# manager.Event().wait()  # We'll block here until a worker calls `event.set()`
p.terminate() # Terminate all processes in the Pool

# TODO: clear memory (variable = None), multithread classification?
# (faster bringing sharing memory variables to main thread, and parallel (need GPU memory growth))
# Parallel GPU might not increase speed due to memory reloading
