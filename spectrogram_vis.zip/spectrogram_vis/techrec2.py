import uhd
usrp = uhd.usrp.MultiUSRP("serial=3135A2A")

sr = 20e06

doreceive = True
while(doreceive):
    samples = usrp.recv_num_samps(5 * int(sr), freq=2437e6, rate=sr)
    print(samples.shape)
    print(samples)
    doreceive = input("Press enter to continue (exit with q)\n") != "q"
