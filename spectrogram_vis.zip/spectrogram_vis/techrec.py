import uhd
usrp = uhd.usrp.MultiUSRP("serial=30AA08D")

sr = 20e06

doreceive = True
while(doreceive):
    samples = usrp.recv_num_samps(5 * int(sr), freq=2412e6, rate=sr)
    print(samples.shape)
    doreceive = input("Press enter to continue (exit with q)\n") != "q"
