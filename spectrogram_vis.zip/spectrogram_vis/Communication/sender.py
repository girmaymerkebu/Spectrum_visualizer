import zmq
import time
import settings
import numpy as np
import proto.msg_tech_rec_pb2 as proto_msg

class Sender:
    def __init__(self):
        self.context = zmq.Context()
        self.socket = self.context.socket(zmq.PUB)
        self.socket.bind("tcp://%s:%s" % (settings.ip_address_pub,settings.port_number_pub))


    def send(self, message_id):
        #Creating main message
        report = proto_msg.TechRecReport()
        report.report_id = message_id
        #Creating a message to store information about channel usage
        for ch in np.arange(0, 12):
            channel_usage = report.channels_usage.add()
            channel_usage.channel = ch

            #Creating report for wifi in this channel
            tech_usage_wifi = channel_usage.tech_usage.add()
            tech_usage_wifi.technology = proto_msg.WiFi
            usage_wifi_pct = np.random.rand()
            tech_usage_wifi.pct_usage = usage_wifi_pct

            #Creating report for LTE in this channel
            tech_usage_lte = channel_usage.tech_usage.add()
            tech_usage_lte.technology = proto_msg.LTE
            usage_lte_pct = 1-usage_wifi_pct
            tech_usage_lte.pct_usage = usage_lte_pct

        print(report)
        self.socket.send(report.SerializeToString())

if __name__ == '__main__':

    sender = Sender()
    print('Start Sending every 5 sec')
    message_id = 1
    while True:
        time.sleep(settings.time_between_reports)
        sender.send(message_id)
        message_id = message_id+1
    print("sender - done")