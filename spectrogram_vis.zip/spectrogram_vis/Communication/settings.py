port_number_pub = '13000'
ip_address_pub = '127.0.0.1'
#ip_address_pub = '10.10.135.167'
# ip_address_pub = '192.168.7.182'
time_between_reports = 5 #in seconds
