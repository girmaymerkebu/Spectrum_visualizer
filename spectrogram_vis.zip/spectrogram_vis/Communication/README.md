# b61-communicator_example
Example code for technology recognition report using ZMQ and Protobuf

The requirement were installed using conda:
conda install -c anaconda pyzmq (zmq + python wrapper)
conda install -c anaconda protobuf

To run the code (python3 was already linked to python exec):

Publisher:
python sender.py

Subscriber:
python receiver.py

