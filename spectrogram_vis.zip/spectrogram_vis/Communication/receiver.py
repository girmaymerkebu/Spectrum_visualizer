import zmq
import proto.msg_tech_rec_pb2 as proto_msg
import settings


class Receiver:
    def __init__(self):
        self.context = zmq.Context()
        self.socket = self.context.socket(zmq.SUB)
        self.socket.setsockopt_string(zmq.SUBSCRIBE, '')
        self.socket.connect("tcp://%s:%s" % (settings.ip_address_pub, settings.port_number_pub))

    def receive(self):
        print('in receive')

        s = self.socket.recv()
        tech_rec_report = proto_msg.TechRecReport()
        tech_rec_report.ParseFromString(s)
        report_id = tech_rec_report.report_id
        print("Message id: ", report_id)
        for ch_usage in tech_rec_report.channels_usage:
            # if ch_usage.channel == 1:
            print(f"Checking usage of channel {ch_usage.channel}")
            for tech_usage in ch_usage.tech_usage:
                if tech_usage.technology == proto_msg.WiFi:
                    print("Usage of WiFi is ", tech_usage.pct_usage)
                elif tech_usage.technology == proto_msg.LTE:
                        print("Usage of LTE is ", tech_usage.pct_usage)
                elif tech_usage.technology == proto_msg.BLE:
                    print("Usage of BLE is ", tech_usage.pct_usage)
                elif tech_usage.technology == proto_msg.Overlap:
                    print("Usage of Overlap is ", tech_usage.pct_usage)
                elif tech_usage.technology == proto_msg.Noise:
                    print("Usage of Noise is ", tech_usage.pct_usage)
        print("")

if __name__ == '__main__':
    receiver = Receiver()
    print('Start Receiving')
    while (True):
        receiver.receive()
