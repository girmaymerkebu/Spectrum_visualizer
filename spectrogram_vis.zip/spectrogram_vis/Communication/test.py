from sender_tech import Sender
import settings
import time

sender = Sender()
print('Start Sending every 5 sec')
message_id = 1
while True:
    time.sleep(settings.time_between_reports)
    sender.send(message_id, 1, {"Wi-Fi":0.2, "LTE":0.1,"BLE":0.05, "Overlap":0.1, "Noise":0.55})
    sender.send(message_id, 6, {"Wi-Fi":0.2, "LTE":0.1,"BLE":0.05, "Overlap":0.1, "Noise":0.55})
    sender.send(message_id, 11, {"Wi-Fi":0.2, "LTE":0.1,"BLE":0.05, "Overlap":0.1, "Noise":0.55})
    message_id = message_id+1
print("sender - done")