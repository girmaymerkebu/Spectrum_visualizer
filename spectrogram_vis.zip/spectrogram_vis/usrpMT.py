import multiprocessing
import numpy as np
import concurrent.futures
import threading
import time
import uhd

arr_devices = [{"freq":2412e6, "serial":"30AA08D"},{"freq":2437e6 , "serial":"3135A2A"}]
arr_usrp = []

sr = 20e06

thread_local = threading.local()

def captureusrp(usrp_id):
    # if(usrp_id==1):
        # time.sleep(0.1)
    device = arr_devices[usrp_id]
    usrp = arr_usrp[usrp_id]
    print(f"Capturing {device['serial']}")
    
    samples = np.empty([1, 5 * int(sr)])

    samples = usrp.recv_num_samps(5 * int(sr), freq=device["freq"], rate=sr)
    print(samples.shape)

    print(f"Finished {device['serial']}")

def processusrp(usrps):
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
        executor.map(captureusrp, usrps)


if __name__ == "__main__":
    start_time = time.time()
    usrp0 = uhd.usrp.MultiUSRP(f"serial={arr_devices[0]['serial']}")
    usrp1 = uhd.usrp.MultiUSRP(f"serial={arr_devices[1]['serial']}")

    arr_usrp.append(usrp0)
    arr_usrp.append(usrp1)
    
    samples = np.empty([1, 5 * int(sr)])

    processusrp([0,1])
    duration = time.time() - start_time
    print(f"Tested in {duration} seconds")
    
    doreceive = True
    while(doreceive):
        processusrp([0,1])
        doreceive = input("Press enter to continue (exit with q)\n") != "q"
