from PIL import Image
with Image.open('Images/1.jpg' ) as img1:
    img1.show()

with Image.open('Images/2.jpg' ) as img2:
    img2.show()


# import webbrowser
# webbrowser.open('Images/1.jpg')
# webbrowser.open('Images/2.jpg')


import time
# Your code as above
time.sleep(30)