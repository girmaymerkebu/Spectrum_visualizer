import results
from enum import Enum
import asyncio
import websockets
import time
import re
import subprocess
import numpy as np
import logging
import tensorflow as tf
from scipy import stats
from scipy.io import savemat
#from tensorflow.keras.backend import set_session
# import pandas as pd
from scipy import signal
import matplotlib.pyplot as plt
import concurrent.futures
from sklearn.preprocessing import minmax_scale
logger = logging.getLogger('websockets')
logger.setLevel(logging.INFO)
logger.addHandler(logging.StreamHandler())

# --- VARIABLES---
connected_clients = set()
result_e = Enum("result_e", 'SPEC POWR LABL')
fs = 20e6  # sampling rate
sens_shot = 2000  # sample bin for classification

visualisation_time = 0.250  # s
visualisation_samples = int(fs * visualisation_time)
visualisation_labels = int(int(fs / sens_shot) * 0.25)

do_IQ = False
modelFFT = "Models/modelfftv19-vgood.h5"
modelIQ = "Models/model_IQ.h5"

channel1 = '2412000000'
channel6 = '2437000000'
channel11 = '2462000000'

measure_location = 'measure.bin' # R:\

# race condition, normally only one thread should write this one.
IQ_data = []

# --- FUNCTIONS WIRELESS CLASSIFICATION ---


def domeasure():
    # Benchmark time
    start = time.time()

    # Capture data
    # out, _ = subprocess.Popen([r'rx_samples_to_file.exe',
    #                            '--file', measure_location,
    #                            '--rate', '20000000',
    #                            '--freq', channel1,  # '2437000000',
    #                            '--type', 'short',
    #                            '--duration', '2.5',
    #                            '--gain', '10',],
    #                            stdout=subprocess.PIPE).communicate() # stdout=subprocess.PIPE # verbose

    # Benchmark results
    end = time.time()
    print("[USRP] Elapsed time: {:.3f} seconds.\n".format(end - start))
    time.sleep(6)
    return end


def doprocess():
    # Read data
    with open(measure_location, "rb") as fid:  # infocomhall5
        data_array = np.fromfile(fid, np.short)
    # print("Read shape of {}".format(data_array.shape)) # verbose

    # Process data
    IQ_data = data_array.T.reshape((int(data_array.shape[0]/2), 2)).T
    # print("Reshaped to {}".format(IQ_data.shape)) # verbose
    # print("Data example \n I: {}\n Q: {}".format( # verbose
        # IQ_data[0, 0:15], IQ_data[1, 0:15]))
    return IQ_data


def docalc_spec(IQ_data):
    print("[SPEC]\tStarted generation...")
    start = time.time()

    # take .25 sec
    IQ_data_temp = IQ_data[:, :visualisation_samples]  # .25s

    # create complex samples
    result = np.empty(IQ_data_temp.shape[1], dtype=complex)
    result.real = IQ_data_temp[0, :]
    result.imag = IQ_data_temp[1, :]

    # create spectrogram
    f, t, Sxx = signal.spectrogram(
        result, fs, return_onesided=False, nperseg=128, nfft=128)

    # reduce precision of spectrogram
    reduce_res = 20
    Sxx = Sxx[:, 0:Sxx.shape[1] - Sxx.shape[1] % reduce_res]

    # make values follow a logarithmic scale
    Sxx = np.fft.fftshift(Sxx, axes=0)
    Sxx = 10*np.log10(abs(Sxx))

    # normalize data between 0 and 99 (for smaller JSON string output)
    sV = Sxx.shape[0]
    sH = Sxx.shape[1]
    Sxx = Sxx.reshape(sV * sH, 1)
    Sxx = Sxx.reshape(-1, reduce_res).mean(axis=1)
    Sxx = minmax_scale(Sxx, feature_range=(0, 99), axis=0, copy=True)
    Sxx = Sxx.reshape(sV, int(sH / reduce_res)).transpose()
    Sxx = Sxx.astype(np.uint8)

    end = time.time()
    print("[SPEC]\tDone, elapsed time: {:.3f} seconds.\n".format(end - start))
    return Sxx.tolist(), result_e.SPEC


def docalc_power(IQ_data):
    print("[POWR]\tStarted generation...")
    start = time.time()
    # take .25 sec
    IQ_data_temp = IQ_data[0, :visualisation_samples]  # .25s

    # reduce precision of power plot
    reduce_res = 100  # IQ length must be dividable

    result_power = np.median(IQ_data_temp.reshape(-1, reduce_res), axis=1)
    result_power = result_power.astype(np.int16) # todo change order with below?


    end = time.time()
    print("[POWR]\tDone, elapsed time: {:.3f} seconds.\n".format(end - start))
    return result_power.tolist(), result_e.POWR


def doclassify(IQ_data, model):
    print("[CLAS]\tStarted generation...")
    start = time.time()
    shorter = IQ_data[:, 0:IQ_data.shape[1] - IQ_data.shape[1] % sens_shot]
    result = np.empty(shorter.shape[1], dtype=complex)
    result.real = shorter[0, :]
    result.imag = shorter[1, :]
    result = np.reshape(result, (int(result.shape[0] / sens_shot), sens_shot))
    if(do_IQ):
        data = result
    else:
        data = np.fft.fft(result, axis=1)

    vdata = minmax_scale(np.concatenate(
        [data.real, data.imag], axis=1), feature_range=(-1, 1), axis=1, copy=True)
    vdata = np.reshape(vdata, (result.shape[0], 250, 16, 1)) # reshape

    with graph.as_default():
        predictions = model.predict_classes(vdata, batch_size=512, verbose=1)

    end = time.time()
    print("[CLAS]\tDone, elapsed time: {:.3f} seconds.\n".format(end - start))
    return predictions.tolist(), result_e.LABL

def dostatistics(labels):
    print("[STAT]\tStarted statistics...")
    start = time.time()
    # Calculate spectrum occupancy & packet size
    spec_occ = dict({0:0,1:0,2:0,3:0,4:0,5:0})
    arr_pack_sizes = dict({0:[], 1:[], 2:[],3:[],4:[]})
    last_packet = -1
    for label in labels:
        spec_occ[label] = spec_occ.get(label, 0) + (1 / len(labels) * 100) # percentage

        # count packet sizes
        if(label != 5):
            if(label == last_packet):
                arr_pack_sizes[label][-1] += 0.1 # -> 100 µs to 1 ms
            else:
                arr_pack_sizes[label].append(0.1) # -> 100 µs to 1 ms
                last_packet = label

    # Calculate inter packet intervals
    pac_ints = dict({0:[[],[]],1:[[],[]],2:[[],[]],3:[[],[]],4:[[],[]]})
    for i in range(0, 4):
        # pac_ints[i] = packet_interval(labels, i)
        arr_ints = packet_interval(labels, i)
        # savemat("pack_int_tech_" + str(i) + ".mat", {"pack_int_values": arr_ints})

        # Calculate packet interval distribution
        if(len(arr_ints)):
            res = stats.relfreq(arr_ints, numbins=20, defaultreallimits=(min(arr_ints, default=0.1), np.percentile(arr_ints, 90)))
            x = res.lowerlimit + np.linspace(0, res.binsize*res.frequency.size,
                                    res.frequency.size)
            pac_ints[i] = [list(x) , list(res.frequency * 100)]

    pack_sizes = dict({0:[[],[]],1:[[],[]],2:[[],[]],3:[[],[]],4:[[],[]]})
    # Calculate packet size distribution
    for i in range(0, 5):
        arr_packs = arr_pack_sizes[i]
        # savemat("pack_siz_tech_" + str(i) + ".mat", {"pack_siz_values": arr_ints})
        if(len(arr_packs)):
            res = stats.relfreq(arr_packs, numbins=20, defaultreallimits=(min(arr_packs, default=0.1), np.percentile(arr_packs, 100)))
            x = res.lowerlimit + np.linspace(0, res.binsize*res.frequency.size, res.frequency.size)
            pack_sizes[i] = [list(x) , list(res.frequency * 100)]

    end = time.time()
    print("[STAT]\tDone, elapsed time: {:.3f} seconds.\n".format(end - start))
    return spec_occ, pac_ints, pack_sizes

def packet_interval(labels, tech):
    class_ind = [i for i, j in enumerate(labels) if j == tech]
    overlap_ind = [i for i, j in enumerate(labels) if j == 4]
    new_class_ind = np.union1d(class_ind, overlap_ind)
    temp1 = []
    for i in range(0, len(new_class_ind)-1):
        if new_class_ind[i+1]-new_class_ind[i]!=1:
            t = new_class_ind[i+1] - new_class_ind[i] - 1 # - 0.1ms for not including last position (same tech)
            t = t / 10  # -> 100 µs to 1 ms
            temp1.append(t) 

    return temp1

async def usrp_loop(queue):
    while(True):
        with concurrent.futures.ThreadPoolExecutor() as pool:
            print("[USRP] Meausuring data ...")
            m_out, _ = await asyncio.wait([asyncio.get_event_loop().run_in_executor(pool, domeasure)])

            end_time = list(m_out)[0].result()
            begin_time = end_time - 2.5 + 7200 # utc fix
            end_time_vis = begin_time + 0.25

            # Process and classify data
            print("Processing and classifying data ...")
            p_out, _ = await asyncio.wait([asyncio.get_event_loop().run_in_executor(pool, doprocess)])
            IQ_data = list(p_out)[0].result()

            await queue.put((IQ_data, begin_time, end_time_vis))


async def wireless_classification(queue):
    if do_IQ:
        model = tf.keras.models.load_model(modelIQ)
    else:
        model = tf.keras.models.load_model(modelFFT)


    global graph
    graph = tf.get_default_graph()

    while(True):
        with concurrent.futures.ThreadPoolExecutor() as pool:
            # Get USRP measurements from queue
            (IQ_data, begin_time, end_time_vis) = await queue.get()

            # Do calculation spectrogram + IQ
            print("Doing calculation ...")
            c_out_s = [asyncio.get_event_loop().run_in_executor(pool, docalc_spec, IQ_data),
                       asyncio.get_event_loop().run_in_executor(pool, docalc_power, IQ_data),
                       asyncio.get_event_loop().run_in_executor(pool, doclassify, IQ_data, model)]

            json_result = results.result()
            arr_labels = []

            # Collect results, run multi-threaded
            for f in asyncio.as_completed(c_out_s, loop=asyncio.get_event_loop()):
                taskresult, res = await f

                if (res == result_e.SPEC):
                    json_result.spec = results.spec(taskresult,  # raw
                                                    [len(taskresult), len(taskresult[0])], begin_time, end_time_vis, visualisation_time / len(taskresult))  # meta
                elif (res == result_e.POWR):
                    json_result.powr = results.powr(taskresult,  # raw
                                                    [len(taskresult)], begin_time, end_time_vis, visualisation_time / len(taskresult))  # meta
                elif(res == result_e.LABL):
                    json_result.labels = results.labels(taskresult[:visualisation_labels],  # raw
                                                    [len(taskresult[:visualisation_labels])], begin_time, end_time_vis, visualisation_time / len(taskresult[:visualisation_labels]))  # meta
                    arr_labels = taskresult 

            # Calculate statistics based on collected labels
            s_out, _ = await asyncio.wait([asyncio.get_event_loop().run_in_executor(pool, dostatistics, arr_labels)])
            spec_occ, pack_int, pack_siz  = list(s_out)[0].result()
            json_result.spec_occ = spec_occ
            json_result.pack_int = pack_int
            json_result.pack_siz = pack_siz

            # import pickle

            # file = open('dump.txt', 'wb')
            # pickle.dump(json_result, file)
            # file.close()

            # export_results(json_result)

        # Send results to connected clients
        if connected_clients:
            #await asyncio.wait([con.send("I'm sending you stuff") for con in connected_clients])
            await asyncio.wait([con.send(json_result.toJSON()) for con in connected_clients])
            print("[SENDING] I've sent the results to {} connected client(s)".format(
                len(connected_clients)))

        print("----- Waiting for new data -----")
        queue.task_done()


def export_results(json_result):
    # Export to json file
    with open("Output.json", "w") as text_file:
        text_file.write(json_result.toJSON())

    # Export spectrogram
    fig = plt.figure(figsize=(30, 1), dpi=320,)
    plt.imshow(np.array(json_result.spec.arr).transpose(),
               cmap='viridis',  aspect='auto')
    plt.colorbar()
    plt.ylabel('Frequency [Hz]')
    plt.xlabel('Time [sec]')
    fig.savefig("spectrogram.pdf")

    # Export
    fig = plt.figure(figsize=(30, 1), dpi=320,)
    lines = plt.plot(json_result.powr.arr)
    plt.ylabel('Amplitude')
    plt.xlabel('Time [sec]')
    plt.setp(lines, linewidth=0.1, color='r')
    fig.savefig("Power.pdf")

    fig = plt.figure(figsize=(30, 3), dpi=320,)
    lines = plt.plot(json_result.labels.arr)
    plt.ylabel('Pred')
    plt.xlabel('Time [sec]')
    plt.setp(lines, linewidth=0.5, color='r')
    fig.savefig("Prediction.pdf")

# --- FUNCTIONS WEBSOCKETS ---
async def producer():
    message = "Hello, World!"
    # print("OUT: Local message: hello world {}".format(len(connected_clients)))
    await asyncio.sleep(1)  # sleep for 5 seconds before returning message
    return message


async def consumer(message):
    print("IN: I've got a new message:\n\t{}".format(message))


async def consumer_handler(websocket, path):
    async for message in websocket:
        await consumer(message)


async def producer_handler(websocket, path):
    await websocket.send("[INFO] Welcome client!")
    while True:  # spawn for each connection
        message = await producer()
        # await websocket.send(message)


async def handler(websocket, path):
    # Add client to local list
    connected_clients.add(websocket)
    try:
        consumer_task = asyncio.ensure_future(
            consumer_handler(websocket, path))
        producer_task = asyncio.ensure_future(
            producer_handler(websocket, path))
        done, pending = await asyncio.wait([consumer_task, producer_task], return_when=asyncio.FIRST_COMPLETED, )

        for task in pending:
            print("Killing pending tasks for lost connection")
            task.cancel()

    except Exception:
        print("Woops something went wrong with the connection")

    finally:
        # Unregister clients
        connected_clients.remove(websocket)
        websocket.close()
        print("Removing connection")


# --- CREATE WEBSOCKET ---
start_server = websockets.serve(handler, 'localhost', 8766, max_size=2**22)

# --- Run WIRELESS CLASSIFICATION AND WEBSOCKET ---
queue = asyncio.Queue()
asyncio.get_event_loop().run_until_complete(
    asyncio.gather(usrp_loop(queue), wireless_classification(queue), start_server))
asyncio.get_event_loop().run_forever()
